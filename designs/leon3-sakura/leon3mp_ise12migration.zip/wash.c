#include <stdio.h>
#include <time.h>
#include <stdlib.h>

inline void storemem(int addr, int val)
{
asm volatile (" stb %0, [%1] " // store val to addr
: // output
: "r" (val), "r" (addr) // inputs
);
}


inline int loadmem(int addr)
{
int tmp; // used for returned value
asm volatile (" ld [%1], %0 " // load tmp from addr
: "=r" (tmp) // output
: "r" (addr) // input
);
return tmp;
}
main() {
 // volatile int *pio = (int *) 0x80000300;
  
 // pio[2] |= 0x3; /* Set direction of line 1 to output */
 // pio[1] |= 0x2; /* Set line 1 high */
/*
 * pio[0] = din
 * pio[1] = dout
 * pio[2] = dir
 * pio[3] = imask
 * pio[4] = level
 * pio[5] = edge
 * pio[6] = bypass
 * pio[7] = reserved
 * pio[8] = irqmap
 */
  

  //printf("Hello\n");
 /* int a = 0;
  int i = 0;
  
  while (a != 200) {
	a++;
  }*
  
  //pio[2] |= 0x3; /* Set direction of line 1 to output */
  //pio[1] |= 0x3; /* Set line 1 high */
  /* printf("out loop\n");
  printf("out loop\n");
  printf("out loop\n");
  printf("out loop\n");
  printf("out loop\n");
  printf("out loop\n");*/
  //printf("out loop\n"); 
  
 //***************************** TEST LOAD
 int i =0;
 int random = 0;
 
 
 asm (" set  0x00000000, %l5 ");
 asm (" set  0x00000000, %l6 ");
 
 for (i=0; i < 100; i++)
 {
	random = rand();
	storemem(2684376240, 0); // store random number in 0xa00054b0
	asm (" set  0xa00054b0, %o2 "); // set o2 to the address of random number
 	
	asm (" set  0xa00154bb, %o3 "); // set o2 to the address of random number
	asm (" add %l6,1,%l6 ");
	asm(" ldub  [ %o2 ], %g7");
	asm (" stb  %g7, [ %o3 + %l6 ]");
	}
	
	asm (" set  0xa00154bb, %o2 "); // set o2 to the address of random number
 for (i=0; i < 100; i++)
 {
	
 	asm (" add %o2,1,%o2 ");
		
	
	asm(" nop ");
	asm(" nop ");
	asm(" nop ");
	asm(" nop ");
	asm(" nop "); 
	asm(" nop ");
	asm(" nop ");
	asm(" nop ");
	asm(" nop ");
	asm(" nop "); 
	asm(" ldub  [ %o2 ], %g1"); // load random number from g1 
	asm(" nop ");
	asm(" nop ");
	asm(" nop ");
	asm(" nop ");
	asm(" nop "); 
	asm(" nop ");
	asm(" nop ");
	asm(" nop ");
	asm(" nop ");
	asm(" nop "); 
	asm (" set  0xa00054bb, %o3 "); // set o2 to the address of random number
	asm (" add %l5,1,%l5 ");
	//asm (" ldub  [ %o3 + %l5 ], %l3 ");
	asm (" stb  %g1, [ %o3 + %l5 ]");
 } 
 /* while(1);
 while(1);
 while(1);
 while(1);
 while(1); */
} 
